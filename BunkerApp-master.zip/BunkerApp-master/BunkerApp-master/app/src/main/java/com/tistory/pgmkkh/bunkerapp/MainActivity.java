package com.tistory.pgmkkh.bunkerapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = (Button)findViewById(R.id.Button1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), FirstView.class);
                startActivity(intent);

                private ListView createAdapter2() {

                    //어댑터 준비 (리소스 배열 객체 이용, simple_list_item_1 리소스 사용
                    ArrayAdapter<CharSequence> adapt
                            = ArrayAdapter.createFromResource(
                            this,
                            R.array.items,
                            android.R.layout.simple_list_item_1);
                    return adapt;

                }
                private ListView createAdapter3()  {


                    String[] items = {"item1", "item2", "item3", "item4", "item5", "item6", "item7", "item8"};


                    ArrayAdapter<String> adapt
                            = new ArrayAdapter<String>(
                            this,
                            R.layout.item,
                            items);

                    return adapt;

                    ArrayAdapter<String> adapt = new ArrayAdapter<String>(this, R.layout.item, items);
                }
                    }
                });


            }
        }
